const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const MONGO_URL = process.env.MONGO_URL;

mongoose.connect(MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true })
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB error', err));

const UserSchema = new mongoose.Schema({
  userId: { type: Number, required: true, unique: true },
  invitedBy: { type: Number, default: null },
  referralCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);

// ===== add referral endpoint =====
app.post('/api/referral', async (req, res) => {
  try {
    const { userId, inviterId } = req.body;
    if (!userId) return res.status(400).json({ status: 'error', message: 'userId required' });

    // stop duplicate: user unique by userId
    const existing = await User.findOne({ userId });
    if (existing) {
      return res.json({ status: 'exists', message: 'User already registered' });
    }

    // create user
    const u = new User({ userId, invitedBy: inviterId || null });
    await u.save();

    // increment inviter's referralCount only if inviter exists and is not same as user
    if (inviterId && inviterId !== userId) {
      await User.updateOne({ userId: inviterId }, { $inc: { referralCount: 1 } });
    }

    return res.json({ status: 'ok', message: 'Referral counted' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: 'error', message: 'Server error' });
  }
});

// ===== admin: list users (protected by simple secret) =====
app.get('/api/admin/users', async (req, res) => {
  const secret = req.headers['x-admin-secret'] || req.query.secret;
  if (!secret || secret !== process.env.ADMIN_SECRET) return res.status(401).json({ status: 'unauthorized' });

  const users = await User.find().sort({ referralCount: -1 }).limit(1000).lean();
  return res.json({ status: 'ok', users });
});

// optional: get single user
app.get('/api/user/:id', async (req, res) => {
  const user = await User.findOne({ userId: Number(req.params.id) }).lean();
  if (!user) return res.json({});
  return res.json(user);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
